'use client'
import { useEffect, useRef, useState } from 'react'
import { useGSAP } from '@gsap/react'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import Image from 'next/image'
import RainbowText from './RainbowText'

gsap.registerPlugin(useGSAP, ScrollTrigger)

// Port direct de <section class="mission-section" id="histoire"> (index.html).
// Desktop : diaporama scroll-driven — la section reste pinnée pendant que
// le scroll avance par crans (4, un par paragraphe/média). À chaque cran,
// le paragraphe se révèle (RainbowText immediate, remonté via key pour
// rejouer le reveal) pendant que le média change en fondu : 1 photo puis
// 3 vidéos qui bouclent (seule celle du cran actif joue réellement — les
// autres restent en pause, pas de lecture simultanée).
// Mobile : désactivé (pas de pin/scroll-jack ni de vidéo) — repli simple,
// les 4 paragraphes empilés sous la photo seule.
const STEPS = [
  {
    text: "Chez Florence est un élevage familial installé à Azaguié Gare, à trente minutes d'Abidjan.",
    media: { type: 'image' as const, src: '/IMAGES/eleveur-soin.jpg' },
  },
  {
    text: "Nous élevons et sélectionnons nos lapins de race — Hollandais, Rex, Angora Français — avec la même attention à chaque portée : pesée précise, suivi de santé, accompagnement du choix jusqu'à la remise.",
    media: { type: 'video' as const, src: '/IMAGES/3.webm' },
  },
  {
    text: "Particuliers, restaurateurs ou éleveurs PME repartent avec un lapin dont on connaît l'histoire depuis le premier jour.",
    media: { type: 'video' as const, src: '/IMAGES/5.webm' },
  },
  {
    text: 'Retrait sur place à Azaguié Gare ou livraison à Abidjan, Agboville et Adzopé — toujours par WhatsApp, toujours avec la même exigence.',
    media: { type: 'video' as const, src: '/IMAGES/4.webm' },
  },
]

export default function MissionSection() {
  const sectionRef = useRef<HTMLElement>(null)
  const videoRefs = useRef<(HTMLVideoElement | null)[]>([])
  const [activeStep, setActiveStep] = useState(0)
  const [isDesktop, setIsDesktop] = useState(true)

  useEffect(() => {
    const mq = window.matchMedia('(min-width: 901px)')
    setIsDesktop(mq.matches)
    const onChange = (e: MediaQueryListEvent) => setIsDesktop(e.matches)
    mq.addEventListener('change', onChange)
    return () => mq.removeEventListener('change', onChange)
  }, [])

  // Ne joue que la vidéo du cran actif — jamais les 3 en même temps.
  useEffect(() => {
    if (!isDesktop) return
    STEPS.forEach((step, i) => {
      const v = videoRefs.current[i]
      if (!v) return
      if (i === activeStep) v.play().catch(() => {})
      else v.pause()
    })
  }, [activeStep, isDesktop])

  useGSAP(() => {
    if (!isDesktop) return () => {}
    const section = sectionRef.current
    if (!section) return () => {}

    const st = ScrollTrigger.create({
      trigger: section,
      start: 'top top',
      end: '+=300%',
      pin: true,
      onUpdate: (self) => {
        const step = Math.min(STEPS.length - 1, Math.floor(self.progress * STEPS.length))
        setActiveStep((prev) => (prev === step ? prev : step))
      },
    })
    return () => st.kill()
  }, [isDesktop])

  return (
    <section className="mission-section" id="histoire" data-theme="maroon" ref={sectionRef}>
      <div className="mission-layout">
        <div className="mission-text-col">
          <div className="eyebrow">No. 02 — Notre Histoire</div>
          <div className="mission-text-huge elastic-title">
            Nous élevons
            <br />
            avec
            <br />
            <span style={{ color: 'var(--rust)' }}>soin.</span>
          </div>

          {isDesktop ? (
            <>
              <div className="mission-description">
                <RainbowText key={activeStep} text={STEPS[activeStep].text} variant="white" immediate />
              </div>
              <div className="mission-steps-dots" aria-hidden="true">
                {STEPS.map((_, i) => (
                  <span key={i} className={`mission-step-dot${i === activeStep ? ' is-active' : ''}`} />
                ))}
              </div>
            </>
          ) : (
            <div className="mission-description mission-description--stacked">
              {STEPS.map((step, i) => (
                <p key={i}>{step.text}</p>
              ))}
            </div>
          )}
        </div>

        <div className="mission-image-col reveal-text">
          {isDesktop ? (
            STEPS.map((step, i) => (
              <div key={i} className={`mission-slide${i === activeStep ? ' is-active' : ''}`}>
                {step.media.type === 'video' ? (
                  <video
                    ref={(el) => { videoRefs.current[i] = el }}
                    src={step.media.src}
                    muted
                    loop
                    playsInline
                    preload={i === 1 ? 'auto' : 'none'}
                  />
                ) : (
                  <Image
                    src={step.media.src}
                    alt="Éleveur Chez Florence prenant soin d'un lapin"
                    fill
                    sizes="(max-width: 900px) 100vw, 38vw"
                    style={{ objectFit: 'cover' }}
                    priority
                  />
                )}
              </div>
            ))
          ) : (
            <Image
              src="/IMAGES/eleveur-soin.jpg"
              alt="Éleveur Chez Florence prenant soin d'un lapin"
              fill
              sizes="100vw"
              style={{ objectFit: 'cover' }}
            />
          )}
        </div>
      </div>
    </section>
  )
}
